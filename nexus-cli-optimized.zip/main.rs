fn main() {
    println!("Nexus CLI running");
}
