// main entry point
fn main() { println!("Hello Nexus CLI"); }